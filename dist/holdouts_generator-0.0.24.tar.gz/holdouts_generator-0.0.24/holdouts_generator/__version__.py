"""Current version of package holdouts_generator"""
__version__ = "0.0.24"